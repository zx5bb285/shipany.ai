import Empty from "@/components/blocks/empty";

export default function () {
  return <Empty message="Admin System" />;
}
