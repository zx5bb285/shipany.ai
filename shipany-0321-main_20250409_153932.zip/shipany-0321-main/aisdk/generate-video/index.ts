export { generateVideo } from "./generate-video";
export type {
  GenerateVideoResult,
  GeneratedVideo,
} from "./generate-video-result";
