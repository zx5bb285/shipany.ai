import { VideoModelV1, VideoModelV1CallWarning } from "@/aisdk/provider";

export type VideoModel = VideoModelV1;

export type VideoGenerationWarning = VideoModelV1CallWarning;
