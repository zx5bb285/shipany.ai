export type KlingImageModelId = "kling-v1";

export interface KlingImageSettings {
  maxImagesPerCall?: number;
}
