export type KlingVideoModelId = "kling-v1" | "kling-v1-6";

export interface KlingVideoSettings {
  maxVideosPerCall?: number;
}
