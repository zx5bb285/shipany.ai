import { ReactNode } from "react";

export interface ContextValue {
  [propName: string]: any;
}
