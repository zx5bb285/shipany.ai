declare module "google-one-tap";
