export interface Apikey {
  api_key: string;
  title: string;
  user_uuid: string;
  created_at: string;
  status: string;
}
